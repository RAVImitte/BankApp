import React from 'react'

const Withdrawl = () => {
    console.log('withdreaw page');
    return(
        <>
            <h1>Withdrawl</h1>
           <input type='text' placeholder="Enter id to search"></input>
       </>
       );
}

export default Withdrawl