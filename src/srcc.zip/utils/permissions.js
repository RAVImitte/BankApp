export const permissions = {
    depositor:['deposit'],
    withdrawer:['withdrawl'],
    accountant:['deposit','withdrawl'],
    manager:['manage','deposit','withdrawl']
}