import React, { useState } from "react";
import { useAuth } from "../auth/useAuth";
import { users } from "../utils/users";

const Login = () => {
  const { login } = useAuth();
  const [username,setUsername] = useState();
  const handleLogin = () => {
    console.log("loggedin");
    login(username);
  };

  const handleSelect = (event) =>{
    setUsername(event.target.value);
    // console.log(event.target.value);
  }
  return (
    <div>
      <select onChange={handleSelect} >
        <option value="none" defaultValue  hidden>Select an Option</option>
        {users.map((user) => (
          <option  key={user.role} value={user.name}>
            {user.name} {user.role}
          </option>
        ))}
      </select>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;
