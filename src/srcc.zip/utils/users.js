export const users = [
    {
        name:'ravi1',
        role:'accountant'
    },
    {
        name:'ravi2',
        role:'manager'
    },
    {
        name:'ravi3',
        role:'depositor'
    },
    {
        name:'ravi4',
        role:'withdrawer'
    }
]

