function Deposit() {
    console.log("deposit page");
    return(
     <>
        <h1>Deposit</h1>
        <input type='text' placeholder="Enter id to search"></input>
    </>
    );
};
export default Deposit;